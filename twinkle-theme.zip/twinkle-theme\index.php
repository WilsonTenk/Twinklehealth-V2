<?php get_header(); ?>

<div class="container mx-auto px-4 py-20">
    <h1 class="text-4xl font-bold mb-8">Welcome to Twinkle Health Foundation</h1>
    <p>This is the fallback page. Please create pages in WordPress admin to see content.</p>
</div>

<?php get_footer(); ?>